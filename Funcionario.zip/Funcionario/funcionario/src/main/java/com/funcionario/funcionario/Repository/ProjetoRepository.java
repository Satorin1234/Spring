package com.funcionario.funcionario.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.funcionario.funcionario.Model.Projeto;

public interface ProjetoRepository extends JpaRepository<Projeto, Long> {
    
}
