package com.funcionario.funcionario.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.funcionario.funcionario.Model.Funcionario;

public interface FuncionarioRepository extends JpaRepository<Funcionario, Long> {
    
}
